# Visual Programming Games (C# Windows Forms)

## Requirements
- Windows 10/11
- Visual Studio 2022 with the **.NET desktop development** workload
- .NET 8 SDK

## Run
1. Extract the ZIP.
2. Open `VisualProgrammingGames.csproj` in Visual Studio.
3. Allow restore if prompted.
4. Press **F5**.

## Included
- Main game hub with Ludo, Chess, Tic-Tac-Toe and About/Credits.
- Main window close protection while a game window is open.
- Four-player turn-based Ludo with dice, token selection, home/finish states and sound cues.
- Chess board with Unicode chess-piece glyphs, local two-player turns and a local chat panel.
- Two-player Tic-Tac-Toe with win/draw detection and reset.
- Developer credit: Uneba Rana; Instructor: Sir Muhammad Abdullah.

## Important implementation notes
- The Ludo implementation is a compact race-style classroom version using four tokens per player and a shared 52-step track; it is not a full commercial Ludo rules engine with the traditional four colored quadrants, safe squares, blockades and exact home lanes.
- Chess includes a board, alternating turns, basic movement validation, captures and an in-window local chat panel. It does not yet implement check/checkmate, castling, en-passant, promotion, online networking or a complete tournament-grade chess rules engine.
- Chess chat is local to the same running application window. For two remote computers, a server/client networking layer is required.
- Sound cues use built-in Windows system sounds, so no external audio files are required.
- Source was generated as a clean standalone project because the existing project files were not supplied. It does not merge into or modify the user's original project.
