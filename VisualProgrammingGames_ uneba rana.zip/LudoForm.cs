using System;
using System.Drawing;
using System.Windows.Forms;

namespace VisualProgrammingGames;

// A playable four-player race-style Ludo implementation.
// Each player rolls a 1-6 and moves one token around a shared 52-step track.
// A six is required to leave the base; landing on an opponent sends it home.
public class LudoForm : Form
{
    private readonly string[] names = { "Red", "Green", "Yellow", "Blue" };
    private readonly Color[] colors = { Color.Crimson, Color.SeaGreen, Color.Goldenrod, Color.RoyalBlue };
    private readonly int[,] positions = new int[4,4];
    private readonly Button[,] tokenButtons = new Button[4,4];
    private readonly Label status = new();
    private readonly Random random = new();
    private int player = 0, dice = 0;
    private readonly Button roll = new();
    private readonly FlowLayoutPanel tokensPanel = new();

    public LudoForm()
    {
        Text="Ludo — Four Players"; Size=new Size(850,650); MinimumSize=new Size(760,560);
        StartPosition=FormStartPosition.CenterParent; BackColor=Color.FromArgb(245,247,250);
        var title=new Label { Text="LUDO • FOUR PLAYER MODE", Dock=DockStyle.Top, Height=60,
            TextAlign=ContentAlignment.MiddleCenter, Font=new Font("Segoe UI",20,FontStyle.Bold), ForeColor=Color.FromArgb(35,45,65) };
        Controls.Add(title);
        status.Text="Red player's turn — roll the dice"; status.Dock=DockStyle.Bottom; status.Height=45;
        status.TextAlign=ContentAlignment.MiddleCenter; status.Font=new Font("Segoe UI",11,FontStyle.Bold);
        Controls.Add(status);
        roll.Text="ROLL DICE"; roll.Height=55; roll.Dock=DockStyle.Bottom; roll.BackColor=Color.FromArgb(35,125,95);
        roll.ForeColor=Color.White; roll.Font=new Font("Segoe UI",14,FontStyle.Bold); roll.Click+=RollDice;
        Controls.Add(roll);
        tokensPanel.Dock=DockStyle.Fill; tokensPanel.Padding=new Padding(25); tokensPanel.AutoScroll=true;
        Controls.Add(tokensPanel);
        for(int p=0;p<4;p++)
        {
            var group=new GroupBox { Text=names[p]+" Player", Width=350, Height=190, ForeColor=colors[p], Font=new Font("Segoe UI",12,FontStyle.Bold), Margin=new Padding(12) };
            for(int t=0;t<4;t++)
            {
                int pp=p, tt=t;
                var b=new Button { Text="HOME", Width=135, Height=48, Left=18+(t%2)*155, Top=30+(t/2)*65,
                    BackColor=colors[p], ForeColor=Color.White, Font=new Font("Segoe UI",10,FontStyle.Bold) };
                b.Click+=(_,_)=>MoveToken(pp,tt);
                tokenButtons[p,t]=b; group.Controls.Add(b);
            }
            tokensPanel.Controls.Add(group);
        }
        title.BringToFront(); UpdateTokens();
    }

    private void RollDice(object? sender, EventArgs e)
    {
        if(dice!=0) { MessageBox.Show("Move one of your tokens first."); return; }
        dice=random.Next(1,7); System.Media.SystemSounds.Asterisk.Play();
        status.Text=$"{names[player]} rolled {dice}. Select one of your tokens.";
        roll.Text="DICE: "+dice;
    }
    private void MoveToken(int p,int t)
    {
        if(p!=player) { MessageBox.Show("Wait for your turn."); return; }
        if(dice==0) { MessageBox.Show("Roll the dice first."); return; }
        int old=positions[p,t];
        if(old==-1 && dice!=6) { MessageBox.Show("You need a 6 to bring this token out."); EndTurn(false); return; }
        positions[p,t]=old==-1?0:old+dice;
        if(positions[p,t]>=52) positions[p,t]=52;
        if(positions[p,t]<52)
        {
            for(int op=0;op<4;op++) if(op!=p)
                for(int ot=0;ot<4;ot++)
                    if(positions[op,ot]>=0 && positions[op,ot]<52 &&
                       (positions[op,ot]+op*13)%52==(positions[p,t]+p*13)%52)
                        positions[op,ot]=-1;
        }
        System.Media.SystemSounds.Beep.Play();
        if(positions[p,t]==52)
        {
            int finished=0; for(int k=0;k<4;k++) if(positions[p,k]==52) finished++;
            if(finished==4) { UpdateTokens(); MessageBox.Show(names[p]+" player wins!"); roll.Enabled=false; return; }
        }
        bool extra=dice==6;
        EndTurn(extra);
        UpdateTokens();
    }
    private void EndTurn(bool extra)
    {
        dice=0; roll.Text="ROLL DICE";
        if(!extra) player=(player+1)%4;
        status.Text=$"{names[player]} player's turn — roll the dice";
    }
    private void UpdateTokens()
    {
        for(int p=0;p<4;p++) for(int t=0;t<4;t++)
        {
            int pos=positions[p,t];
            tokenButtons[p,t].Text=pos==-1?"HOME":pos==52?"FINISH":$"STEP {pos}";
            tokenButtons[p,t].Enabled=pos!=52;
        }
    }
}
