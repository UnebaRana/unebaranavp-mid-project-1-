using System;
using System.Drawing;
using System.Windows.Forms;

namespace VisualProgrammingGames;

public class TicTacToeForm : Form
{
    private readonly Button[] cells = new Button[9];
    private char turn = 'X';
    private bool finished;

    public TicTacToeForm()
    {
        Text = "Tic-Tac-Toe"; Size = new Size(460, 540);
        StartPosition = FormStartPosition.CenterParent; BackColor = Color.FromArgb(25, 34, 54);
        var title = new Label { Text = "TIC-TAC-TOE", Dock = DockStyle.Top, Height = 65,
            TextAlign = ContentAlignment.MiddleCenter, ForeColor = Color.White,
            Font = new Font("Segoe UI", 22, FontStyle.Bold) };
        Controls.Add(title);
        var board = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(25),
            RowCount = 3, ColumnCount = 3 };
        for (int i=0;i<3;i++) { board.RowStyles.Add(new RowStyle(SizeType.Percent, 33.33f)); board.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,33.33f)); }
        for (int i=0;i<9;i++)
        {
            int index=i;
            cells[i] = new Button { Dock=DockStyle.Fill, Margin=new Padding(5), Text="",
                Font=new Font("Segoe UI",32,FontStyle.Bold), BackColor=Color.WhiteSmoke, FlatStyle=FlatStyle.Flat };
            cells[i].Click += (_,_) => Play(index);
            board.Controls.Add(cells[i], i%3, i/3);
        }
        Controls.Add(board);
        var reset = new Button { Text="New Game", Dock=DockStyle.Bottom, Height=48, BackColor=Color.MediumPurple, ForeColor=Color.White };
        reset.Click += (_,_) => Reset();
        Controls.Add(reset);
        title.BringToFront();
    }

    private void Play(int i)
    {
        if (finished || cells[i].Text!="") return;
        cells[i].Text=turn.ToString();
        System.Media.SystemSounds.Beep.Play();
        if (HasWon(turn)) { finished=true; MessageBox.Show($"Player {turn} wins!"); return; }
        if (Array.TrueForAll(cells, c=>c.Text!="")) { finished=true; MessageBox.Show("It is a draw!"); return; }
        turn = turn=='X'?'O':'X';
        Text=$"Tic-Tac-Toe — Player {turn}";
    }
    private bool HasWon(char p)
    {
        string s=p.ToString();
        int[,] lines={{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};
        for(int i=0;i<8;i++) if(cells[lines[i,0]].Text==s && cells[lines[i,1]].Text==s && cells[lines[i,2]].Text==s) return true;
        return false;
    }
    private void Reset() { foreach(var c in cells)c.Text=""; turn='X'; finished=false; Text="Tic-Tac-Toe"; }
}
