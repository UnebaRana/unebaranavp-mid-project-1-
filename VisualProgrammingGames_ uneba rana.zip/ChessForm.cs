using System;
using System.Drawing;
using System.Windows.Forms;

namespace VisualProgrammingGames;

// Two-player local chessboard UI with piece selection, alternating turns and basic
// piece movement validation. This teaching version does not implement check/checkmate,
// castling, en-passant or promotion.
public class ChessForm : Form
{
    private readonly Button[,] squares = new Button[8,8];
    private readonly string[,] board = new string[8,8];
    private readonly bool[,] white = new bool[8,8];
    private bool whiteTurn=true;
    private Point? selected=null;
    private readonly Label turnLabel=new();
    private readonly TextBox chatInput=new();
    private readonly ListBox chatLog=new();

    private static readonly string[,] start = {
        {"♜","♞","♝","♛","♚","♝","♞","♜"},
        {"♟","♟","♟","♟","♟","♟","♟","♟"},
        {"","","","","","","",""},
        {"","","","","","","",""},
        {"","","","","","","",""},
        {"","","","","","","",""},
        {"♙","♙","♙","♙","♙","♙","♙","♙"},
        {"♖","♘","♗","♕","♔","♗","♘","♖"}
    };

    public ChessForm()
    {
        Text="Chess — Two Players"; Size=new Size(1000,760); MinimumSize=new Size(900,680);
        StartPosition=FormStartPosition.CenterParent; BackColor=Color.FromArgb(28,35,49);
        for(int r=0;r<8;r++) for(int c=0;c<8;c++) { board[r,c]=start[r,c]; white[r,c]=r>=6; }
        var title=new Label { Text="CHESS", Dock=DockStyle.Top, Height=55, ForeColor=Color.White,
            TextAlign=ContentAlignment.MiddleCenter, Font=new Font("Segoe UI",20,FontStyle.Bold) };
        Controls.Add(title);
        var layout=new TableLayoutPanel { Dock=DockStyle.Fill, ColumnCount=2, Padding=new Padding(18) };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,72)); layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,28));
        var grid=new TableLayoutPanel { Dock=DockStyle.Fill, RowCount=8, ColumnCount=8, Margin=new Padding(0) };
        for(int i=0;i<8;i++){grid.RowStyles.Add(new RowStyle(SizeType.Percent,12.5f));grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,12.5f));}
        for(int r=0;r<8;r++) for(int c=0;c<8;c++)
        {
            int rr=r,cc=c;
            squares[r,c]=new Button { Dock=DockStyle.Fill, Margin=Padding.Empty, FlatStyle=FlatStyle.Flat,
                BackColor=(r+c)%2==0?Color.FromArgb(238,225,196):Color.FromArgb(119,83,59),
                ForeColor=r<2?Color.Black:Color.White, Font=new Font("Segoe UI Symbol",31,FontStyle.Regular) };
            squares[r,c].FlatAppearance.BorderSize=0; squares[r,c].Click+=(_,_)=>SquareClick(rr,cc);
            grid.Controls.Add(squares[r,c],c,r);
        }
        layout.Controls.Add(grid,0,0);
        var side=new Panel { Dock=DockStyle.Fill, Padding=new Padding(12), BackColor=Color.FromArgb(38,48,67) };
        turnLabel.Dock=DockStyle.Top; turnLabel.Height=50; turnLabel.ForeColor=Color.White;
        turnLabel.Font=new Font("Segoe UI",12,FontStyle.Bold); side.Controls.Add(turnLabel);
        var chatTitle=new Label { Text="PLAYER CHAT (LOCAL)", Dock=DockStyle.Top, Height=35, ForeColor=Color.White, TextAlign=ContentAlignment.MiddleLeft };
        side.Controls.Add(chatTitle);
        chatLog.Dock=DockStyle.Fill; side.Controls.Add(chatLog);
        var sendPanel=new Panel { Dock=DockStyle.Bottom, Height=82 };
        chatInput.Dock=DockStyle.Top; chatInput.PlaceholderText="Type a message...";
        var send=new Button { Text="Send", Dock=DockStyle.Bottom, Height=35, BackColor=Color.SteelBlue, ForeColor=Color.White };
        send.Click+=(_,_)=>SendChat(); chatInput.KeyDown+=(_,e)=>{if(e.KeyCode==Keys.Enter){SendChat();e.SuppressKeyPress=true;}};
        sendPanel.Controls.Add(chatInput); sendPanel.Controls.Add(send); side.Controls.Add(sendPanel);
        layout.Controls.Add(side,1,0); Controls.Add(layout); title.BringToFront();
        UpdateBoard();
    }

    private void SquareClick(int r,int c)
    {
        if(selected==null)
        {
            if(board[r,c]=="" || white[r,c]!=whiteTurn) return;
            selected=new Point(c,r); squares[r,c].BackColor=Color.Khaki; return;
        }
        int sr=selected.Value.Y, sc=selected.Value.X;
        if(sr==r && sc==c){selected=null;UpdateBoard();return;}
        if(board[r,c]!="" && white[r,c]==whiteTurn){selected=new Point(c,r);UpdateBoard();squares[r,c].BackColor=Color.Khaki;return;}
        if(IsLegal(sr,sc,r,c))
        {
            board[r,c]=board[sr,sc]; white[r,c]=white[sr,sc]; board[sr,sc]="";
            whiteTurn=!whiteTurn; System.Media.SystemSounds.Beep.Play();
        }
        selected=null; UpdateBoard();
    }

    private bool IsLegal(int sr,int sc,int r,int c)
    {
        string piece=board[sr,sc]; int dr=r-sr, dc=c-sc;
        if(board[r,c]!="" && white[r,c]==whiteTurn) return false;
        bool pathClear=true;
        int stepR=Math.Sign(dr), stepC=Math.Sign(dc), x=sr+stepR,y=sc+stepC;
        while(x!=r || y!=c){if(board[x,y]!="")pathClear=false;x+=stepR;y+=stepC;}
        switch(piece)
        {
            case "♙": return whiteTurn ? (dc==0 && dr==-1 && board[r,c]=="" || dc==0 && dr==-2 && sr==6 && board[sr-1,sc]=="" && board[r,c]=="" || Math.Abs(dc)==1 && dr==-1 && board[r,c]!="") :
                (dc==0 && dr==1 && board[r,c]=="" || dc==0 && dr==2 && sr==1 && board[sr+1,sc]=="" && board[r,c]=="" || Math.Abs(dc)==1 && dr==1 && board[r,c]!="");
            case "♟": return !whiteTurn && (dc==0 && dr==1 && board[r,c]=="" || dc==0 && dr==2 && sr==1 && board[sr+1,sc]=="" && board[r,c]=="" || Math.Abs(dc)==1 && dr==1 && board[r,c]!="");
            case "♖": case "♜": return (dr==0 || dc==0) && pathClear;
            case "♗": case "♝": return Math.Abs(dr)==Math.Abs(dc) && pathClear;
            case "♕": case "♛": return (dr==0 || dc==0 || Math.Abs(dr)==Math.Abs(dc)) && pathClear;
            case "♘": case "♞": return Math.Abs(dr)*Math.Abs(dc)==2;
            case "♔": case "♚": return Math.Max(Math.Abs(dr),Math.Abs(dc))==1;
        }
        return false;
    }

    private void UpdateBoard()
    {
        for(int r=0;r<8;r++)for(int c=0;c<8;c++)
        {
            squares[r,c].Text=board[r,c];
            squares[r,c].ForeColor=white[r,c]?Color.White:Color.Black;
            squares[r,c].BackColor=(r+c)%2==0?Color.FromArgb(238,225,196):Color.FromArgb(119,83,59);
        }
        turnLabel.Text=whiteTurn?"White player's turn":"Black player's turn";
    }
    private void SendChat()
    {
        string msg=chatInput.Text.Trim(); if(msg=="")return;
        chatLog.Items.Add((whiteTurn?"White: ":"Black: ")+msg);
        chatInput.Clear(); System.Media.SystemSounds.Asterisk.Play();
    }
}
