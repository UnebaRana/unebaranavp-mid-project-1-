using System;
using System.Windows.Forms;

namespace VisualProgrammingGames;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}
