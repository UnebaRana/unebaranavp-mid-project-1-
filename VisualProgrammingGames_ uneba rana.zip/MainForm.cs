using System;
using System.Drawing;
using System.Windows.Forms;

namespace VisualProgrammingGames;

public class MainForm : Form
{
    private int runningGames = 0;
    public MainForm()
    {
        Text = "Game Hub | Visual Programming Project";
        StartPosition = FormStartPosition.CenterScreen;
        Size = new Size(900, 650);
        MinimumSize = new Size(760, 560);
        BackColor = Color.FromArgb(20, 27, 45);
        BuildUi();
        FormClosing += MainForm_FormClosing;
    }

    private void BuildUi()
    {
        var header = new Label {
            Text = "GAME HUB", Dock = DockStyle.Top, Height = 100,
            TextAlign = ContentAlignment.MiddleCenter, ForeColor = Color.White,
            Font = new Font("Segoe UI", 28, FontStyle.Bold)
        };
        Controls.Add(header);

        var subtitle = new Label {
            Text = "Choose a game and play", Dock = DockStyle.Top, Height = 38,
            TextAlign = ContentAlignment.MiddleCenter, ForeColor = Color.LightSteelBlue,
            Font = new Font("Segoe UI", 12)
        };
        Controls.Add(subtitle);

        var grid = new TableLayoutPanel {
            Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2,
            Padding = new Padding(90, 30, 90, 30), BackColor = Color.Transparent
        };
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        grid.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        grid.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        grid.Controls.Add(MakeButton("LUDO  •  4 PLAYERS", Color.FromArgb(32, 150, 110), () => OpenGame(new LudoForm())), 0, 0);
        grid.Controls.Add(MakeButton("CHESS  •  2 PLAYERS", Color.FromArgb(60, 110, 190), () => OpenGame(new ChessForm())), 1, 0);
        grid.Controls.Add(MakeButton("TIC-TAC-TOE", Color.FromArgb(150, 90, 175), () => OpenGame(new TicTacToeForm())), 0, 1);
        grid.Controls.Add(MakeButton("ABOUT / CREDITS", Color.FromArgb(90, 100, 120), ShowCredits), 1, 1);
        Controls.Add(grid);

        var footer = new Label {
            Text = "Developed by Uneba Rana  |  Guided by Sir Muhammad Abdullah",
            Dock = DockStyle.Bottom, Height = 42, TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = Color.Gainsboro, Font = new Font("Segoe UI", 9, FontStyle.Italic)
        };
        Controls.Add(footer);
        header.BringToFront();
        subtitle.BringToFront();
    }

    private Button MakeButton(string text, Color color, Action action)
    {
        var b = new Button { Text = text, Dock = DockStyle.Fill, Margin = new Padding(14),
            BackColor = color, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 15, FontStyle.Bold), Cursor = Cursors.Hand };
        b.FlatAppearance.BorderSize = 0;
        b.Click += (_, _) => { System.Media.SystemSounds.Asterisk.Play(); action(); };
        return b;
    }

    private void OpenGame(Form game)
    {
        runningGames++;
        game.FormClosed += (_, _) => runningGames--;
        game.Show(this);
    }

    private void ShowCredits()
    {
        MessageBox.Show("Visual Programming Lab Mid Project\n\nDeveloped by: Uneba Rana\nInstructor: Sir Muhammad Abdullah\n\nGames: Ludo, Chess and Tic-Tac-Toe",
            "About / Credits", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void MainForm_FormClosing(object? sender, FormClosingEventArgs e)
    {
        if (runningGames > 0)
        {
            e.Cancel = true;
            MessageBox.Show("You cannot close the application while a game is running.",
                "Game is running", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
